public class LinkedListOfAcidente {

    private class Node {
        public Acidente element;
        public Node next;

        public Node(Acidente a) {
            this.element= a;
            next = null;
        }

        public Node(Acidente a, Node n){
            this.element = a;
            this.next = n;
        }
    }

    private Node head;
    private Node tail;
    private int count;

    public LinkedListOfAcidente() {
        head = null;
        tail = null;
        count = 0;
    }

    public void add(Acidente a) {
        Node n = new Node(a);
        if (head == null) {
            head = n;
        } else {
            tail.next = n;
        }
        tail = n;
        count++;
    }

    public int numeroAcidentes(){
        return count;
    }    

    public int getTotalAcidentesMoto() {
        int contaAcidMoto = 0;
        Node aux = head;
        for (int i = 0; i < count; i++) {
            Acidente acidente = aux.element;
            if (acidente.getAcidentesMoto() > 0) {
                contaAcidMoto++;
            }
            aux = aux.next;
        }
        return contaAcidMoto;
    }

    public boolean isEmpty(){
        return (head == null);
    }

    public void clear(){
        head = null;
        tail = null;
        count = 0;
    }

    public Acidente get(int index) { 
        if ((index < 0) || (index >= count)) {
            throw new IndexOutOfBoundsException();
        }
        if (index == count-1)
            return tail.element;
        
        Node aux = head;
        int c = 0;
        while (c < index) {
            aux = aux.next;
            c++;
        }
        return (aux.element);
    }

    public String getDiaDaSemanaMaisAcidentes(){
        Node aux = head;
        int contSeg = 0,
            contTer = 0, 
            contQua = 0, 
            contQui = 0, 
            contSex = 0, 
            contSab = 0, 
            contDom = 0;

        for (int i = 0; i < count; i++) {
            Acidente acidente = aux.element;
            if ((acidente.getDiaDaSemana()).equals("SEGUNDA-FEIRA")) {
                contSeg++;
            }
            else if ((acidente.getDiaDaSemana()).equals("TERCA-FEIRA")) {
                contTer++;
            }
            else if ((acidente.getDiaDaSemana()).equals("QUARTA-FEIRA")) {
                contQua++;
            }
            else if ((acidente.getDiaDaSemana()).equals("QUINTA-FEIRA")) {
                contQui++;
            }
            else if ((acidente.getDiaDaSemana()).equals("SEXTA-FEIRA")) {
                contSex++;
            }
            else if ((acidente.getDiaDaSemana()).equals("SABADO")) {
                contSab++;
            }
            else if ((acidente.getDiaDaSemana()).equals("DOMINGO")) {
                contDom++;
            }
            aux = aux.next;
        }
        
        if(contSeg >= contTer && contSeg >= contQua && contSeg >= contQui && contSeg >= contSex && contSeg >= contSab && contSeg >= contDom){
            return "SEGUNDA-FEIRA";
        } 
        else if(contTer >= contSeg && contTer >= contQua && contTer >= contQui && contTer >= contSex && contTer >= contSab && contTer >= contDom){
            return "TERCA-FEIRA";
        } 
        else if(contQua >= contSeg && contQua >= contTer && contQua >= contQui && contQua >= contSex && contQua >= contSab && contQua >= contDom){
            return "QUARTA-FEIRA";
        } 
        else if(contQui >= contSeg && contQui >= contTer && contQui >= contQua && contQui >= contSex && contQui >= contSab && contQui >= contDom){
            return "QUINTA-FEIRA";
        } 
        else if(contSex >= contSeg && contSex >= contTer && contSex >= contQua && contSex >= contQui && contSex >= contSab && contSex >= contDom){
            return "SEXTA-FEIRA";
        } 
        else if(contSab >= contSeg && contSab >= contTer && contSab >= contQua && contSab >= contQui && contSab >= contSex && contSab >= contDom){
            return "SABADO";
        } 
        else if(contDom >= contSeg && contDom >= contTer && contDom >= contQua && contDom >= contQui && contDom >= contSex && contDom >= contSab){
            return "DOMINGO";
        } 
        return " ";
    }

}
