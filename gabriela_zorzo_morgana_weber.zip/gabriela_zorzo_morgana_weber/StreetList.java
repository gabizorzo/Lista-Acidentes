import org.w3c.dom.Node;

public class StreetList {
    private Node header;
    private Node trailer;
    private int count;
    private Node current;

    private class Node {
        public String nomeLogradouro;
        public LinkedListOfAcidente listaAcidentes;
        public Node next;
        public Node prev;

        public Node(String nomeLog) {
            this.nomeLogradouro = nomeLog;
            listaAcidentes = new LinkedListOfAcidente();
            next = null;
            prev = null;
        }

        public void add(Acidente a) {
            listaAcidentes.add(a);
        }
    }

    public StreetList() {
        header = new Node(null);
        trailer = new Node(null);
        header.next = trailer;
        trailer.prev = header;
        count = 0;
    }

    public void addAcidente(Acidente a) {
        String rua = a.getNomeLog();
        boolean achou = false;

        if (header.next != trailer) {
            Node aux = header.next;

            while (!achou && (aux != trailer)) {
                String nomeRua = aux.nomeLogradouro;
                if (nomeRua.compareTo(rua) == 0) {
                    aux.add(a);
                    achou = true;
                }
                aux = aux.next;
            }

            if (!achou){
                addOrdenado(a.getNomeLog(), a);
            }
        } else {
            Node n = new Node(a.getNomeLog());
            n.add(a);
            header.next = n;
            trailer.prev = n;

            n.next = trailer;
            n.prev = header;
        }

    }

    public void addOrdenado(String nomeLog, Acidente a) {
        Node aux = header.next;
        Node n = new Node(nomeLog);
        n.add(a);

        while (aux != trailer) {
            String nomeRua = aux.nomeLogradouro;

            if (nomeRua.compareTo(nomeLog) < 0)
                aux = aux.next;
            else if (nomeRua.compareTo(nomeLog) > 0) {
                Node aux2 = aux.prev;
                n.next = aux;
                n.prev = aux.prev;

                aux2.next = n;
                aux.prev = n;

                count++;
                break;
            }
        }
        if(aux == trailer){
            n.prev = aux.prev;
            n.next = trailer;
            trailer.prev = n;
            n.prev.next = n;
        }
    }

    public void reset() {
        current = header.next;
    }

    public String next() {
        if (current == trailer)
            return null;
        else {
            String i = current.nomeLogradouro;
            current = current.next;
            return i;
        }
    }

    public String prev() {
        if (current == header)
            return null;
        else {
            String i = current.nomeLogradouro;
            current = current.prev;
            return i;
        }
    }

    public String getRuaComMaisAcidentes() {
        String maior = header.next.nomeLogradouro;
        int qtd = 0;
        Node aux = header.next;
        
        while (aux != trailer) {
            if (qtd < aux.listaAcidentes.numeroAcidentes()) {
                maior = aux.nomeLogradouro;
                qtd = aux.listaAcidentes.numeroAcidentes();
            }
            aux = aux.next;
        }  
        return maior;
    }

    public String getDiaDaSemanaMaisAcidentes(String nomeLog){
        Node aux = header.next;

        while (aux != trailer) {
            String nomeRua = aux.nomeLogradouro;
            if (nomeRua.compareTo(nomeLog) == 0) {
                return aux.listaAcidentes.getDiaDaSemanaMaisAcidentes();
            }
            aux = aux.next;
        }  
        return null;
    }

    public int getTotalAcidentesMoto() {
        int contaAcidMoto = 0;
        Node aux = header;
        while (aux != trailer) {
            contaAcidMoto += aux.listaAcidentes.getTotalAcidentesMoto();
            aux = aux.next;
        }
        return contaAcidMoto;
    }

    public void avancar(){
        if(current != trailer) {
            System.out.println(current.nomeLogradouro + " total de acidentes: " + current.listaAcidentes.numeroAcidentes());
            current = current.next;
        }else{
            System.out.print("Voce chegou ao final da lista.");
        }
    }

    public void retroceder(){
        if(current.prev != header){
            current = current.prev;
            System.out.println(current.nomeLogradouro + " total de acidentes: " + current.listaAcidentes.numeroAcidentes());
        }else{
            System.out.println("Voce chegou ao comeco da lista.");
        }
    }

    public void imprimeCurrent(){
        System.out.println(current.nomeLogradouro);
    }
}
