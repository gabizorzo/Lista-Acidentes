import java.time.LocalDateTime;

public class Acidente {
    private String logradouro; 
    private String nomeLog; 
    private String tipoAcidente; 
    private LocalDateTime data; 
    private String diaSemana; 
    private int feridos; 
    private int fatais; 
    private int auto; 
    private int taxis; 
    private int lotacao; 
    private int onibusUrb; 
    private int onibusInt; 
    private int caminhao; 
    private int moto; 
    private int carroca;
    private int bicicleta; 
    private String tempo; 
    private String turno; 
    private String regiao; 

    public Acidente (String log, String nL, String tA, LocalDateTime d, String dS, int fer, int fat, int a, int t, int l, int oU, int oI, int cam, int m, int car, int b, String tempo, String turno, String r) {
        this.logradouro = log;
        this.nomeLog = nL;
        this.tipoAcidente = tA;
        this.data = d;
        this.diaSemana = dS;
        this.feridos = fer;
        this.fatais = fat;
        this.auto = a;
        this.taxis = t;
        this.lotacao = l;
        this.onibusUrb = oU;
        this.onibusInt = oI;
        this.caminhao = cam;
        this.moto = m;
        this.carroca = car;
        this.bicicleta = b;
        this.tempo = tempo;
        this.turno = turno;
        this.regiao = r;
    }
    
    public String getNomeLog(){
        return nomeLog;
    }

    public int getAcidentesMoto(){
        return moto;
    }

    public String getDiaDaSemana(){
        return diaSemana;
    }
}