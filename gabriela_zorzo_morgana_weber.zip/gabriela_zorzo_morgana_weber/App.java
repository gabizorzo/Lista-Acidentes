public class App {
    public static void main(String[] args) {
        Interface i = new Interface();
        i.executa();
    }
}
